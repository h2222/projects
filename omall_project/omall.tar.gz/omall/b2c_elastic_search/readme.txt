1. build dt index
2. write data to dt index
3. check the alias, use new dt alias to root
